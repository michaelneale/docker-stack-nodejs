## Deploying a sample docker app

This uses the docker stack: https://index.docker.io/u/michaelneale/docker-stack-nodejs to run a hello world node.js app.
This is a "trusted build" build by docker, which serves as the foundation for the sample app. 

The sample app is the index.js - amazin, I know. Step back and breathe in the glory. A node.js app. 

# How it works

The docker image: https://github.com/michaelneale/docker-stack-nodejs
is build by docker.io - made available. To run an app - the users app.zip is added to this, environment variables set, port allocated etc.

## How to deploy

Zip up this directory as app.zip: 

        zip -r ../app.zip .

Then deploy to the "pool-62" - the docker pool in beescloud:     

        bees app:deploy -t docker -R PLUGIN.SRC.docker=http://repository-michaelnealeclickstart2.forge.cloudbees.com/release/docker_plugin.zip -R docker.image=michaelneale/docker-stack-nodejs app.zip serverPool=pool-62


This uses the "docker clickstart" which bootstraps docker based apps. The docker.image item specifies the base image to pull down and run. The users app.zip is then placed in /var/app inside the image (and .genapp is placed in the root) - both read only. The app itself runs as a non root user (daemon) inside the container. Any bees config:set variables are made available as environment variables.

A full command example: 

        bees app:deploy -a admin/dockernode3 -k . -s . --server https://api.beescloud.com/api -t docker -R PLUGIN.SRC.docker=http://repository-michaelnealeclickstart2.forge.cloudbees.com/release/docker_plugin.zip -R docker.image=michaelneale/docker-stack-nodejs app.zip serverPool=pool-62



## Building your own stack: 

# developing locally
Start with Dockerfile like mine (grab it from: https://github.com/michaelneale/docker-stack-nodejs), run: 

        docker build -t myimage .

Then to test it with your app.zip - in this case $PWD should be the directory containing the exploded app (in the sample case, it can just be the index.js from this repo): 

        docker run -v $PWD:/var/app myimage
        
And check it runs. This is the workflow for developing things locally.

# publishing your stack

Fork https://github.com/michaelneale/docker-stack-nodejs - or create your own github repo with a Dockerfile in it (make it similar to that - note it listens on port 8080, runs as daemon user, and uses "entrypoint").

Then set it up as a trusted build via docker.io - when it has built your image - you can use it as a basis for your app - using the docker.image command line parameter as shown above. The docker plugin will pull down the image from docker.io index the first time it sees it. 

